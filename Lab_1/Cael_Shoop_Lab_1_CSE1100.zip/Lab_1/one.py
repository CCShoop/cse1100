'''Lab 1 Problem 1 program written by Cael Shoop for CSE1100.'''


def main():
    # Prints the predefined statement
    print('Hello all! This is my first Python program for CSE1100.')


if __name__ == '__main__':
    main()
